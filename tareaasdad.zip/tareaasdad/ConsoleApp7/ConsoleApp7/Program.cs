﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] asistencia = new int[5];
            bool existeCero = false;
            int indiceModificar, nuevoValor;

            // 1. Registrar asistencia de cada sesión
            Console.WriteLine("Ingrese la asistencia de las 5 sesiones:");

            for (int i = 0; i < 5; i++)
            {
                Console.Write($"Sesión {i}: ");
                asistencia[i] = int.Parse(Console.ReadLine());
            }

            // 2. Mostrar asistencias registradas
            Console.WriteLine("\nAsistencias registradas:");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Índice {i}: {asistencia[i]}");
            }

            // 3. Verificar si existe alguna sesión con 0 asistentes
            for (int i = 0; i < 5; i++)
            {
                if (asistencia[i] == 0)
                {
                    existeCero = true;
                }
            }

            if (existeCero)
            {
                Console.WriteLine("\nAlerta: existe una sesión con 0 asistentes");
            }
            else
            {
                Console.WriteLine("\nNo hay sesión con 0 asistentes");
            }

            // 4. Modificar una asistencia indicando su índice
            Console.Write("\nIngrese el índice que desea modificar: ");
            indiceModificar = int.Parse(Console.ReadLine());

            if (indiceModificar >= 0 && indiceModificar < 5)
            {
                Console.Write("Ingrese el nuevo valor: ");
                nuevoValor = int.Parse(Console.ReadLine());

                asistencia[indiceModificar] = nuevoValor;
            }
            else
            {
                Console.WriteLine("Índice no válido");
            }

            // 5. Mostrar asistencias actualizadas
            Console.WriteLine("\nAsistencias actualizadas:");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Índice {i}: {asistencia[i]}");
            }

            Console.ReadKey();
        }
    }
}
