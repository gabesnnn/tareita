﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] precios = new double[5];
            double buscado, nuevo;
            int posicion = -1;

            // Registrar los precios
            for (int i = 0; i < 5; i++)
            {
                Console.Write($"Ingrese el precio {i + 1}: ");
                precios[i] = double.Parse(Console.ReadLine());
            }

            // Precio a buscar
            Console.Write("Ingrese el precio a buscar: ");
            buscado = double.Parse(Console.ReadLine());

            // Buscar el precio
            for (int i = 0; i < 5; i++)
            {
                if (precios[i] == buscado)
                {
                    posicion = i;
                }
            }

            // Modificar si se encontró
            if (posicion != -1)
            {
                Console.Write("Ingrese el nuevo precio: ");
                nuevo = double.Parse(Console.ReadLine());

                precios[posicion] = nuevo;

                Console.WriteLine("Precio actualizado");
            }
            else
            {
                Console.WriteLine("Precio no encontrado");
            }

            // Mostrar arreglo actualizado
            Console.WriteLine("\nLista de precios:");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Posición {i}: {precios[i]}");
            }
        }
    }
}
